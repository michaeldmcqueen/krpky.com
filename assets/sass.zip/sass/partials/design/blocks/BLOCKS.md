BLOCKS
------

Files that should be stored in here are things like logo, navigation, breadcrumbs etc 
Each block should have it's own file.

Use variables from global/variables.
Extend mixins and styles from styleguide.